<?xml version="1.0" encoding="UTF-8"?>
<tileset name="objects" tilewidth="32" tileheight="32" tilecount="8" columns="4">
 <image source="../tilesets/objects.png" width="128" height="64"/>
</tileset>
